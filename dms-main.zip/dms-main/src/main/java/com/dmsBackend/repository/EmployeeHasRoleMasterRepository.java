package com.dmsBackend.repository;

import com.dmsBackend.entity.EmployeeHasRoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeHasRoleMasterRepository extends JpaRepository<EmployeeHasRoleMaster,Integer> {
}
