package com.dmsBackend.repository;

import com.dmsBackend.entity.BranchMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BranchMasterRepository extends JpaRepository<BranchMaster,Integer> {
}
