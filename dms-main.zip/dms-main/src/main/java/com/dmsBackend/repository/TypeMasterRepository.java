package com.dmsBackend.repository;

import com.dmsBackend.entity.TypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeMasterRepository extends JpaRepository<TypeMaster,Integer> {
}
