package com.dmsBackend.repository;

import com.dmsBackend.entity.RoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleMasterRepository extends JpaRepository<RoleMaster, Integer> {
}
