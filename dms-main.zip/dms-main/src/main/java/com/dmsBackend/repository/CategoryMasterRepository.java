package com.dmsBackend.repository;

import com.dmsBackend.entity.CategoryMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryMasterRepository extends JpaRepository<CategoryMaster,Integer> {
}
