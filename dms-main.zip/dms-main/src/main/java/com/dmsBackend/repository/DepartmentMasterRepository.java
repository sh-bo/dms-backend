package com.dmsBackend.repository;

import com.dmsBackend.entity.DepartmentMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentMasterRepository extends JpaRepository<DepartmentMaster,Integer> {
}
