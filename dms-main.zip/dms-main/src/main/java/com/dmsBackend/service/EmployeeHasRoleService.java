package com.dmsBackend.service;

import com.dmsBackend.entity.EmployeeHasRoleMaster;

public interface EmployeeHasRoleService {
    EmployeeHasRoleMaster saved(EmployeeHasRoleMaster employeeHasRoleMaster);
}
