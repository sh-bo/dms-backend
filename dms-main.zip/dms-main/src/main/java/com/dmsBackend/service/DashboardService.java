package com.dmsBackend.service;

import com.dmsBackend.response.DashboardResponse;

public interface DashboardService {

DashboardResponse getAllUsers();
}
